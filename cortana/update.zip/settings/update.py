import urllib2
import os
import xbmcgui
import zipfile
import ssl

def download_file(url, dest):
    try:
        # Define the User Agent string to Mozilla Firefox
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0'}

        # Create a request object with headers
        req = urllib2.Request(url, headers=headers)
        
        # Setup SSL context if needed (uncomment if SSL/TLS issues persist)
        # ctx = ssl.create_default_context()
        # ctx.check_hostname = False
        # ctx.verify_mode = ssl.CERT_NONE

        # Open the URL (add context=ctx to urlopen if SSL context is used)
        u = urllib2.urlopen(req)  # , context=ctx if SSL/TLS issues are handled with context
        with open(dest, 'wb') as f:
            file_size = int(u.info().getheaders("Content-Length")[0])
            dialog = xbmcgui.DialogProgress()
            dialog.create('Download Progress', 'Downloading update...')

            file_size_dl = 0
            block_sz = 8192
            while True:
                buffer = u.read(block_sz)
                if not buffer:
                    break

                file_size_dl += len(buffer)
                f.write(buffer)
                percent = file_size_dl * 100. / file_size
                dialog.update(int(percent))

                if dialog.iscanceled():
                    f.close()
                    dialog.close()
                    os.remove(dest)
                    return False
            dialog.close()
            return True
    except Exception as e:
        dialog = xbmcgui.Dialog()
        dialog.ok('Error', 'Failed to download file: ' + str(e))
        return False

# Example use
def main():
    url = 'http://lain.ftp.sh/cortana/update.zip'
    destination_path = 'Q:\\scripts\\Cortana Server Browser\\update.zip'
    extract_path = 'Q:\\scripts\\Cortana Server Browser'

    if not os.path.exists(extract_path):
        os.makedirs(extract_path)

    if download_file(url, destination_path):
        print("Download successful")
    else:
        print("Download failed")

if __name__ == '__main__':
    main()
