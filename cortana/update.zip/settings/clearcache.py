import xbmcgui
import os
import xbmc

def delete_cache_files():
    cache_folder = "E:\\CACHE"
    found_bin_files = False
    dialog = xbmcgui.Dialog()
    
    for file_name in os.listdir(cache_folder):
        if file_name.endswith(".bin"):
            found_bin_files = True
            os.remove(os.path.join(cache_folder, file_name))
    
    if found_bin_files:
        dialog.ok("Cache Cleared!", "Cache files have been removed.")
    else:
        dialog.ok("No Cache Files Found", "No cache files to clear.")

def main():
    dialog = xbmcgui.Dialog()
    ret = dialog.yesno("Clear Cache", "Would you like to clear the cache?")
    
    if ret:
        delete_cache_files()
    else:
        dialog.ok("Cache Not Cleared", "Cache not cleared!.")
        
    # Execute settings.py regardless of the user's choice
    xbmc.executebuiltin('RunScript(Q:\\scripts\\Cortana Server Browser\\settings\\settings.py)')

if __name__ == "__main__":
    main()
