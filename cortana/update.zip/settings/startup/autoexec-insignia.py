import xbmc
xbmc.executebuiltin('XBMC.RunScript(Q:\\scripts\\Cortana Server Browser\\insignia\\notify.py)')