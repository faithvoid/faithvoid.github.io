import xbmc
xbmc.executebuiltin('XBMC.RunScript(Q:\\scripts\\Cortana Server Browser\\xlink\\notify.py)')